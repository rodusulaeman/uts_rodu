package com.uts.rodusulaeman;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    Spinner combo;

    public String Menu_Makanan[] = {"Jus Alpuket", "Jus Jeruk", "Jus Mangga", "Es Campur", "Es Teh Manis Hangat", "Es Bajigur", "Es Dawet"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = (ListView) findViewById(R.id.listmakanan);
        combo = (Spinner) findViewById(R.id.comboMakanan);

        ArrayAdapter adapter = new ArrayAdapter<>(MainActivity.this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item,Menu_Makanan);

        listView.setAdapter(adapter);
        combo.setAdapter(adapter);
    }
}